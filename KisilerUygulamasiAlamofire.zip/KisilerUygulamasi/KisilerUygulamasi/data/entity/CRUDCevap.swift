//
//  CRUDCevap.swift
//  KisilerUygulamasi
//
//  Created by Kasım on 9.08.2023.
//

import Foundation

class CRUDCevap : Codable {
    var success:Int?
    var message:String?
}
